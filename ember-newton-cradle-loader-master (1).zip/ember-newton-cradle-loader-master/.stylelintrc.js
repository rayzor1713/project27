module.exports = {
  extends: 'stylelint-config-ship-shape'
};
